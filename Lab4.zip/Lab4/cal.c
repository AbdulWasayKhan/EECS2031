/***************************************
* EECS2031 � Lab4 *
* Author: Khan, Abdul Wasay *
* Email: awkhan94@my.yorku.ca *
* EECS_num: awkhan94 *
* York Student #: 214981104 *
***************************************/

int x;   // define a global variable
int y;   // define a global variable

void func1 (void) // define a function
{
  x--;
  y++;
}

