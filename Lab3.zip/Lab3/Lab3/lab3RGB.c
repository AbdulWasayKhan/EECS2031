/***************************************
* EECS2031 � Lab3 *
* Author: Khan, Abdul Wasay *
* Email: awkhan94@my.yorku.ca *
* EECS_num: awkhan94 *
* York Student #: 214981104 *
***************************************/

#include <stdio.h>
#include "binaryFunction.c"
#define AlphaValue 100

/*function call*/
void printBinary(int);

int main() {

  int r, g,b;
  unsigned int rgb_pack;
  int r_unpack, g_unpack,b_unpack;
  int alpha = AlphaValue;
  int rEightBits,gEightBits,bEightBits;

  printf("enter R value: ");
  scanf("%d",&r);
  printf("enter G value: ");
  scanf("%d",&g);
  printf("enter B value: ");
  scanf("%d",&b);

  while(! (r<0 || g<0 || b <0) )
  {
     printf("A: %d\t", alpha);
     printBinary(alpha);
     printf("\n");

     printf("R: %d\t", r);
     printBinary(r);
     printf("\n");

     printf("G: %d\t", g);
     printBinary(g);
     printf("\n");

     printf("B: %d\t", b);
     printBinary(b);
     printf("\n");

    /* do the packing */

    rEightBits = r << 16;
    gEightBits = g << 8;
    bEightBits = b;
    rgb_pack = rEightBits | gEightBits | bEightBits | (alpha <<24);

     printf("\nPacked:\t");
     printBinary(rgb_pack);
     printf(" (%d)\n", rgb_pack);
     printf("\nUnpacking  ......\n");

    /* do unpacking */

    /* shifting + masking */
    r_unpack = rgb_pack >> 16 & 255; // or 0Xff  or 0377
    g_unpack = rgb_pack >> 8  & 0Xff;
    b_unpack = rgb_pack >> 0  & 0377;

     printf("R: ");
     printBinary(r_unpack);
     printf(" (%d, %#o, %#X)\n", r_unpack, r_unpack, r_unpack);

     printf("G: ");
     printBinary(g_unpack);
     printf(" (%d, %#o, %#X)\n", g_unpack, g_unpack, g_unpack);

     printf("B: ");
     printBinary(b_unpack);
     printf(" (%d, %#o, %#X)\n", b_unpack, b_unpack, b_unpack);
     printf("------------------------------------\n");

     /* read again */
     printf("\nenter R value: ");
     scanf("%d",&r);
     printf("enter G value: ");
     scanf("%d",&g);
     printf("enter B value: ");
     scanf("%d",&b);

  }

}


