/***************************************
* EECS2031 � Lab3 *
* Author: Khan, Abdul Wasay *
* Email: awkhan94@my.yorku.ca *
* EECS_num: awkhan94 *
* York Student #: 214981104 *
***************************************/

int count;
int sum;
double resu;

void runningAverage(void)
{
    resu = (double) sum/ count;

}
